package com.stg.firstprj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstPrjApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstPrjApplication.class, args);
	}

}
