package com.stg.firstprj.controller;

import com.stg.firstprj.entity.Student;
import com.stg.firstprj.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class StudentController {

    @Autowired
    StudentService service;

    @PostMapping("/save")
    public Student saveStudent(@RequestBody Student student){
        Student savedStudent = service.saveStudent(student);
        return savedStudent;
    }

    @GetMapping("/get/{studentId}")
    public Student getById(@PathVariable Long studentId){
        Student savedStudent = service.getById(studentId);
        return savedStudent;
    }
}
