package com.stg.firstprj.service;

import com.stg.firstprj.entity.Student;
import com.stg.firstprj.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentService {

    @Autowired
    StudentRepository repo;

    public Student saveStudent(Student student) {
        return repo.save(student);
    }

    public Student getById(Long studentId) {

        return repo.findById(studentId).get();
    }
}
