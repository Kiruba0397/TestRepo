package com.stg.firstprj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstPrjApplicationTests {

	@Test
	void contextLoads() {
	}

}
